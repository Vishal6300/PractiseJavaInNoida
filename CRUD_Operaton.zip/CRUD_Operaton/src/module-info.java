/**
 * 
 */
/**
 * @author vkdeo
 *
 */
module CRUD_Operaton {
	requires java.sql;
}