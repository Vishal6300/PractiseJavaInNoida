package myPackage;

public class Main {

	public static void main(String[] args) {
		Student st= new Student();
//		st.createDatabase();
//		st.createTable();
//		st.createData();
//		st.updateData();
//		st.deleteData();
		st.getAllDetails();
		
		
	}

}
