package com.todo.tasks.service;

import java.util.List;

import com.todo.tasks.model.Tasks;

public interface TaskService {
	public List<Tasks> findTaskByFolder(String taskFolderName);
	public List<Tasks> viewAllTasks();
	public Tasks createTask(Tasks task);
}
